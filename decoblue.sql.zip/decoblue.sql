-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 29-11-2013 a las 14:50:47
-- Versión del servidor: 5.6.12-log
-- Versión de PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `decoblue`
--
CREATE DATABASE IF NOT EXISTS `decoblue` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `decoblue`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulo`
--

CREATE TABLE IF NOT EXISTS `articulo` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `cod_art` int(4) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `precio_venta` int(10) NOT NULL,
  `descri_art` text NOT NULL,
  `stock_real` int(10) NOT NULL,
  `stock_min` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cod_art` (`cod_art`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulo_proveedor`
--

CREATE TABLE IF NOT EXISTS `articulo_proveedor` (
  `cant_sum` int(4) NOT NULL,
  `precio` int(10) NOT NULL,
  `cod_art` int(4) NOT NULL,
  `cod_ref` int(4) NOT NULL,
  PRIMARY KEY (`cod_art`,`cod_ref`),
  KEY `cod_ref` (`cod_ref`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `cedula` int(9) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `direccion` text NOT NULL,
  `telefono` varchar(15) NOT NULL,
  PRIMARY KEY (`cedula`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `extranjero`
--

CREATE TABLE IF NOT EXISTS `extranjero` (
  `pais` varchar(15) NOT NULL,
  `pers_cont` varchar(70) NOT NULL,
  `cod_ref` int(4) NOT NULL,
  PRIMARY KEY (`cod_ref`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nacional`
--

CREATE TABLE IF NOT EXISTS `nacional` (
  `rif` varchar(12) NOT NULL,
  `cod_ref` int(4) NOT NULL,
  PRIMARY KEY (`cod_ref`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proovedor`
--

CREATE TABLE IF NOT EXISTS `proovedor` (
  `cod_ref` int(4) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `direccion` text NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `rifp` varchar(20) NOT NULL,
  PRIMARY KEY (`cod_ref`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `user_reg` datetime NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `cedula` int(20) NOT NULL,
  `born_date` date NOT NULL DEFAULT '0000-00-00',
  `email` varchar(40) NOT NULL,
  `pais` varchar(20) NOT NULL,
  `sexo` enum('0','1') NOT NULL DEFAULT '0',
  `user_type` int(2) NOT NULL,
  `descripcion` text NOT NULL,
  `ip` varchar(15) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(25) NOT NULL,
  `online_last` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nick` (`username`,`email`),
  FULLTEXT KEY `nick_2` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE IF NOT EXISTS `venta` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `cod_art` int(4) NOT NULL,
  `cliente_ci` int(11) NOT NULL,
  `cantidad` int(5) NOT NULL,
  `precio` int(10) NOT NULL,
  `tipo_pago` varchar(20) NOT NULL,
  `total` int(10) NOT NULL,
  `id_compra` int(10) NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
